/*
 * main.c / Memory Hierarchy
 *
 * Triet Ngo, Yan To / CS5600 / Northeastern University
 * Fall 2023 / Nov 14, 2023
 *
 */

#include "message.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void unitTest1() {

  printf("---------TEST 1: Create a Message---------\n");
  message_t *newMessage1 = create_msg("Triet", "Justin", "Hello");

  printf("Message should be created with ID = 1. Actual: %d\n", newMessage1->id);
  printf("Message should be created at the current time UTC: %s\n", newMessage1->timeSent);
  printf("Message content should be \"Hello\": %s\n", newMessage1->content);
  printf("Message should be sent from Triet. Actual: %s\n", newMessage1->sender);
  printf("Message should be sent to Justin. Actual: %s\n", newMessage1->receiver);
  printf("Message's deliver status should be 0. Actual: %d\n", newMessage1->delivered);

  free(newMessage1);

  printf("\n");
}


void unitTest2() {

  printf("---------TEST 2: Storing a Message---------\n");
  printf("Create newMessage2, from Zadie to Taron with the message 'What's up?'...\n");
  message_t *newMessage2 = create_msg("Zadie", "Taron", "What's up?");

  store_msg_random(newMessage2);
  
  printf("Storing successful!\n");
  printf("In the newly created file mStorage.txt, there should be the content of newMessage2 with the following data line by line:\n\n");
  
  printf("2\n");
  printf("*Time created in UTC*\n");
  printf("Zadie\n");
  printf("Taron\n");
  printf("What's up?\n");
  printf("1\n");

  printf("\n");
}


void unitTest3() {
  printf("---------TEST 3: Retrieving Message---------\n");
  printf("Create 2 new messages and store them in the mStorage.txt\n");

  printf("Creating and storing 2 new messages...\n");
  message_t *newMessage3 = create_msg("Justin", "Marie", "Let's go to the gym");
  message_t *newMessage4 = create_msg("&%^De;v", "Admin*$(%&", "wefwib3;235;wrg");

  store_msg_random(newMessage3);
  store_msg_random(newMessage4);
  printf("Storing successful!\n\n");
  traverse_cache();

  printf("Retrieving message with ID=2...\n");

  message_t* retrieveTestMsg = retrieve_msg_random(2);

  printf("Retrieved message ID=2. Actual: %d\n", retrieveTestMsg->id);
  printf("Retrieved message created at time indicated in storage file. Actual: %s", retrieveTestMsg->timeSent);
  printf("Retrieved message sent from Justin. Actual: %s", retrieveTestMsg->sender);
  printf("Retrieved message sent to Marie. Actual: %s", retrieveTestMsg->receiver);
  printf("Retrieved message content. Expected: Let's go to the gym. Actual: %s", retrieveTestMsg->content);
  printf("Retrieved message's delivery status is 1. Actual: %d\n\n", retrieveTestMsg->delivered);

  printf("Testing for nonsensical values. Retrieving message with ID=2...\n");

  message_t* retrieveTestMsg2 = retrieve_msg_random(3);

  printf("Retrieved message ID=3. Actual: %d\n", retrieveTestMsg2->id);
  printf("Retrieved message created at time indicated in storage file. Actual: %s", retrieveTestMsg2->timeSent);
  printf("Retrieved message sent from &%%^De;v. Actual: %s", retrieveTestMsg2->sender);
  printf("Retrieved message sent to Admin*$(%%&. Actual: %s", retrieveTestMsg2->receiver);
  printf("Retrieved message content. Expected: wefwib3;235;wrg. Actual: %s", retrieveTestMsg2->content);
  printf("Retrieved message's delivery status is 1. Actual: %d\n", retrieveTestMsg2->delivered);

  printf("\n");
}


void unitTest4() {
  printf("---------TEST 4: Random Replacement---------\n");
  message_t *newMessage0 = create_msg("Sender 0", "Receiver 0", "Content 0");
  message_t *newMessage1 = create_msg("Sender 1", "Receiver 1", "Content 1");
  message_t *newMessage2 = create_msg("Sender 2", "Receiver 2", "Content 2");
  message_t *newMessage3 = create_msg("Sender 3", "Receiver 3", "Content 3");
  message_t *newMessage4 = create_msg("Sender 4", "Receiver 4", "Content 4");
  message_t *newMessage5 = create_msg("Sender 5", "Receiver 5", "Content 5");
  message_t *newMessage6 = create_msg("Sender 6", "Receiver 6", "Content 6");
  message_t *newMessage7 = create_msg("Sender 7", "Receiver 7", "Content 7");
  message_t *newMessage8 = create_msg("Sender 8", "Receiver 8", "Content 8");
  message_t *newMessage9 = create_msg("Sender 9", "Receiver 9", "Content 9");
  message_t *newMessage10 = create_msg("Sender 10", "Receiver 10", "Content 10");
  message_t *newMessage11 = create_msg("Sender 11", "Receiver 11", "Content 11");
  message_t *newMessage12 = create_msg("Sender 12", "Receiver 12", "Content 12");

  store_msg_random(newMessage0);
  store_msg_random(newMessage1);
  store_msg_random(newMessage2);
  store_msg_random(newMessage3);
  store_msg_random(newMessage4);
  store_msg_random(newMessage5);
  store_msg_random(newMessage6);
  store_msg_random(newMessage7);
  store_msg_random(newMessage8);
  store_msg_random(newMessage9);
  store_msg_random(newMessage10);
  store_msg_random(newMessage11);
  store_msg_random(newMessage12);

  printf("Size of cache is %d\n", size_of_cache(cache));

  message_t *newMessage17 = create_msg("Sender 17", "Receiver 17", "Content 17");
  store_msg_random(newMessage17);
  traverse_cache();

  message_t* retrieveCache = retrieve_msg_random(7);
  printf("Retrieved message ID=7. Actual: %d\n", retrieveCache->id);
  printf("Retrieved message created at time indicated in storage file. Actual: %s", retrieveCache->timeSent);
  printf("Retrieved message sent from Justin. Actual: %s", retrieveCache->sender);
  printf("Retrieved message sent to Marie. Actual: %s", retrieveCache->receiver);
  printf("Retrieved message content. Expected: Let's go to the gym. Actual: %s", retrieveCache->content);
  printf("Retrieved message's delivery status is 1. Actual: %d\n\n", retrieveCache->delivered);

}

// void unitTest5(){
//   printf("---------TEST 5: Random Replacement---------\n");
//   message_t* retrieveCache = retrieve_msg_random(16);
//   printf("Retrieved message ID=16. Actual: %d\n", retrieveCache->id);
//   printf("Retrieved message created at time indicated in storage file. Actual: %s", retrieveCache->timeSent);
//   printf("Retrieved message sent from Justin. Actual: %s", retrieveCache->sender);
//   printf("Retrieved message sent to Marie. Actual: %s", retrieveCache->receiver);
//   printf("Retrieved message content. Expected: Let's go to the gym. Actual: %s", retrieveCache->content);
//   printf("Retrieved message's delivery status is 1. Actual: %d\n\n", retrieveCache->delivered);
//   traverse_cache();
// }

void unitTest5() {
  printf("---------TEST 5: Retrieve a Non-Existent Message---------\n");
  printf("Retrieving message with ID 99999, which does not exist.\n");
  printf("Error message should appear\n");
  message_t* retrievedNone = retrieve_msg_LRU(99999);
  printf("\n");
}

// Create 2000 messages and do 1000 random message accessses
void cacheHitAndMiss() {

  printf("---------CALCULATING HIT AND MISS RATIO---------\n");

  // Create 2000 messages and store in the array
  int i;
  for (i = 0; i < 2000; i++) {
    message_t* testMsg = create_msg("Sender", "Receiver", "Content");
    store_msg_random(testMsg);
  }

  // Access 1000 random messages
  srand(time(NULL) + clock());
  for (i = 0; i < 1000; i++) {

    // Get current number of cache misses
    int tempMiss = cacheMiss;
    int randNum = rand() % 1000 + 1;
    message_t* testRetrieved = retrieve_msg_random(randNum);

    // Once a message is retrieved, if tempMiss != cacheMiss,
    // a disk retrieval was performed which will be freed to prevent memory leak
    if (tempMiss != cacheMiss) {
      free(testRetrieved);
    }
  }

  printf("\n");

  printf("Cache hit per 1000: %d\n", cacheHit);
  printf("Cache miss per 1000: %d\n", cacheMiss);
  printf("Cache hit ratio: %d / %d\n", cacheHit, cacheHit + cacheMiss);

}


int main(void) {
  init_cache();

  printf("Running unit tests...\n\n");

  unitTest1();
  unitTest2();
  unitTest3();
  unitTest4();
  unitTest5();
  cacheHitAndMiss();
  
  printf("Tests successful. Exiting...\n");

  free_cache();

  return 0;
}