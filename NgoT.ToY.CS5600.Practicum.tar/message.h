/*
 * message.h / Memory Hierarchy
 *
 * Triet Ngo, Yan To / CS5600 / Northeastern University
 * Fall 2023 / Nov 14, 2023
 *
 */

#ifndef MESSAGE_H
#define MESSAGE_H

#include <stdio.h>
#include <time.h>

// A new structure that is a message with the following attributes
// ID: int
// Time sent: mm/dd/yy hh/mm/ss
// Sender: string
// Receiver: string
// Content: string
// Sent: int (0 or 1)
typedef struct message {
  int id;
  char timeSent[64];
  char sender[128];
  char receiver[128];
  char content[2048];
  int delivered;
} message_t;

extern message_t *cache[16];
extern int usageArr[16];
extern int cacheHit;
extern int cacheMiss;

message_t *create_msg(char mSender[], char mReceiver[], char mContent[]);

void init_cache();

void store_to_cache_random(message_t *msg);

void store_to_cache_LRU(message_t *msg);

void store_msg_random(message_t *msg);

void store_msg_LRU(message_t *msg);

message_t *retrieve_from_cache_random(int mId);

message_t *retrieve_from_cache_LRU(int mId);

message_t *retrieve_msg_random(int mId);

message_t *retrieve_msg_LRU(int mId);

void traverse_cache();

void free_cache();

int size_of_cache(message_t *cacheArray[]);

#endif // MESSAGE_H