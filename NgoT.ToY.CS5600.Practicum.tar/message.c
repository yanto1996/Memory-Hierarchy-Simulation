/*
 * Practicum I
 *
 * Triet Ngo, Yan To / CS5600 / Northeastern University
 * Fall 2023 / Nov 14, 2023
 *
 */
#include "message.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Maximum size of a message struct, chosen arbitrarily
int messageSize = 2380;

// Intialize cache array, usage array, and cache pointer to help track
// current cache pointer position
message_t* cache[16];
int usageArr[16];
int cachePtr = 0;

// ID starts at 0
int mId = 0;

// Cache hit and cache miss variables
int cacheHit = 0;
int cacheMiss = 0;

// This function initializes the cache and sets each element in the cache to NULL and its usage to -1
void init_cache(){
  for (int i = 0; i < 16; i++){
    cache[i] = NULL;
    usageArr[i] = -1;
  }
}

// This function creates a new message with user-determined parameters:
//   mSender: sender name - str
//   mReceiver: receiver name - str
//   mContent: message content - str
message_t *create_msg(char mSender[], char mReceiver[], char mContent[]) {

  // Allocate memory for a new message
  message_t *newMessage = (message_t *)malloc(messageSize);

  // Check for memalloc
  if (newMessage == NULL) {
    printf("Can't create a new message. Aborting...\n");
    return NULL;
  }

  // Set ID
  newMessage->id = mId;
  mId = mId + 1;

  // Find the current time
  time_t currentTime;
  struct tm *timeSent;
  time(&currentTime);
  timeSent = localtime(&currentTime);

  // Get rid of newline from asc time
  char *finalString = asctime(timeSent);
  finalString[strlen(finalString) - 1] = '\0';
  strcpy(newMessage->timeSent, finalString);

  // Initialize the rest of the data
  strcpy(newMessage->content, mContent);
  strcpy(newMessage->sender, mSender);
  strcpy(newMessage->receiver, mReceiver);

  // Delivered Status, either 1 (sent) or 0 (not sent)
  newMessage->delivered = 0;

  return newMessage;
}

// This function traverses the cache and returns the size of the cache
// Each non-NULL cache element will increment the size by 1
int size_of_cache(message_t* cacheArray[]) {
  // Check if the usage array is full
  int size = 0;
  for (int i = 0; i < 16; i++){
    if (cacheArray[i] != NULL){
      size++;
    }
  }

  return size;
}

// This function stores messages to the cache using the random replacement algorithm
// If not full, the message will be stored in the next available space
// If full, the message will be stored in a random space, overwriting if applicable
void store_to_cache_random(message_t* msg) {
  
  // When cache is not full
  if (size_of_cache(cache) < 16) {
    
    // Allocate memory for the message
    message_t* cacheMsg = malloc(sizeof(message_t));
    if (cacheMsg == NULL) {
      printf("Error: Cannot allocate memory for cache message.\n");
      return;
    }

    // Copy the contents of 'msg' to the allocated memory
    memcpy(cacheMsg, msg, sizeof(message_t));
    free(cache[cachePtr]);
    cache[cachePtr] = cacheMsg;
    // Wrap around within the valid range
    cachePtr = (cachePtr + 1) % 16;
    
  } else {
    printf("Cache is full\n");

    // Use a random index for replacement
    srand(time(NULL) + clock());
    int replaceIndex = rand() % 16;
    printf("Replacing cache entry %d\n", replaceIndex);

    // Allocate memory for the message
    message_t* cacheMsg = malloc(sizeof(message_t));
    if (cacheMsg == NULL) {
      printf("Error: Cannot allocate memory for cache message.\n");
      return;
    }

    // Copy the contents of 'msg' to the allocated memory
    memcpy(cacheMsg, msg, sizeof(message_t));
    free(cache[replaceIndex]);
    cache[replaceIndex] = cacheMsg;
  }
}

// This function stores messages to cache using the Least Recently Used (LRU) caching algorithm
// We created a usage array separate from the cache that tracks the usage of each message in cache
// Anytime the cache is accessed "ie stored or retrieved", we increase the usage index by 1
// The message with the highest usage index is the least recently used and that with a usage of 0 is the most recently used
// The function checks if cache is full or not. If not we find the next avail space and store the message in cache
// The function cache is not full, we find the message in the cache with the highest usage and replace that message
void store_to_cache_LRU(message_t* msg) {
  
  // When cache is not full
  if (size_of_cache(cache) < 16) {
    
    // Allocate memory for the message
    message_t* cacheMsg = malloc(sizeof(message_t));
    if (cacheMsg == NULL) {
      printf("Error: Cannot allocate memory for cache message.\n");
      return;
    }

    // Copy the contents of 'msg' to the allocated memory
    memcpy(cacheMsg, msg, sizeof(message_t));
    free(cache[cachePtr]);
    cache[cachePtr] = cacheMsg;

    // Update the usage index accordingly
    for (int i = 0; i < 16; i++){
      if (usageArr[i] != -1 || i != cachePtr){
        usageArr[i]++;
        usageArr[cachePtr] = 0;
      }
    }

    cachePtr++;
  }

  // Else if cache is full
  else {
    
    // Find the highest usage index (least recently used item)
    printf("Cache is full\n");
    int maxUsage = 0;

    for (int j = 0; j < 16; j++) {
      if (usageArr[j] >= maxUsage) {
        maxUsage = usageArr[j];
      }
    }



    // Find the LRU item and replace it
    for (int k = 0; k < 16; k++) {
      if (usageArr[k] == maxUsage) {

        printf("Replacing cache entry %d\n", k);

        cachePtr = k;
        
        // Allocate memory for the message
        message_t* cacheMsg = malloc(sizeof(message_t));
        if (cacheMsg == NULL) {
          printf("Error: Cannot allocate memory for cache message.\n");
          return;
        }

        // Copy the contents of 'msg' to the allocated memory
        memcpy(cacheMsg, msg, sizeof(message_t));
        free(cache[cachePtr]);
        cache[cachePtr] = cacheMsg;
      }
    }

    // Update the usage index accordingly
    for (int i = 0; i < 16; i++){
      if (usageArr[i] != -1 || i != cachePtr){
        usageArr[i]++;
        usageArr[cachePtr] = 0;
      }
    }
  }
}

// This function retrieves a message from the cache
// It scans for the message ID in each each index and if it is found, it will return the message
// Returns NULL if not found in the cache
message_t* retrieve_from_cache_random(int mId){
  for (int i = 0; i < 16; i++){
    message_t* mItr = cache[i];

    if (mId == mItr->id){
      usageArr[i] = 0;
      return mItr;
    }
  }
  return NULL;
}

// This function retrieves a message from a LRU designed cache mechanism
// It updates the usage of each message since we are accessing the cache 
// It scans for the message ID in each each index and if it is found, it will return the message
// Returns NULL if not found in the cache
message_t* retrieve_from_cache_LRU(int mId){

  // Increase usage for all elements in the cache
  for (int i = 0; i < 16; i++){
    if (usageArr[i] != -1 || i != cachePtr){
      usageArr[i]++;
    }
  }

  // Return the message if found
  for (int i = 0; i < 16; i++){
    message_t* mItr = cache[i];

    if (mId == mItr->id){
      usageArr[i] = 0;
      return mItr;
    }
  }

  // Else returns NULL
  return NULL;
}

// This function stores a message to disk and also to the cache with random replacement algorithm
// Once a message has been stored to disk and cache, its delivery status will change to 1
// When storing to cache, if there is space in the cache it will store it in the next avail space
// If not, the store_to_cache_random will run the random replacement algorithm and store to cache
void store_msg_random(message_t *msg) {
  // Store in a file
  FILE *file;

  // Name file
  char *fileName = "mStorage.txt";

  // Create a storage file
  file = fopen(fileName, "a");

  // Check for error
  if (file == NULL) {
    printf("Error: File not found.\n");
    return;
  }

  // Change flag to sent
  msg->delivered = 1;

  // Store message in cache
  store_to_cache_random(msg);

  // Store the message on disk
  fprintf(file, "%d\n%s\n%s\n%s\n%s\n%d\n\n", msg->id, msg->timeSent,
          msg->sender, msg->receiver, msg->content, msg->delivered);

  // Close
  fclose(file);

  // Free memory
  free(msg);
}

// This function stores a message to disk and also to the cache with LRU algorithm
// Once a message has been stored to disk and cache, its delivery status will change to 1
// When storing to cache, if there is space in the cache it will store it in the next avail space
// If not, the store_to_cache_LRU will run the LRU algorithm and store to cache
void store_msg_LRU(message_t *msg) {

  // Store in a file
  FILE *file;

  // Name file
  char *fileName = "mStorage.txt";

  // Create a storage file
  file = fopen(fileName, "a");

  // Check for error
  if (file == NULL) {
    printf("Error: File not found.\n");
    return;
  }

  // Change flag to sent
  msg->delivered = 1;

  // Store message in cache
  store_to_cache_LRU(msg);

  // Store the message on disk
  fprintf(file, "%d\n%s\n%s\n%s\n%s\n%d\n\n", msg->id, msg->timeSent,
          msg->sender, msg->receiver, msg->content, msg->delivered);

  // Close
  fclose(file);

  // Free memory
  free(msg);
}

// This function retrieves and returns a message based on its mID
// It will search through the cache first and if the message is not in the cache it will retrieve from disk
// If the message is found on disk it will retrieve and store it on cache with random replacement
message_t *retrieve_msg_random(int mId) {

  // Attempt to retrieve from cache first
  message_t* retrieved = retrieve_from_cache_random(mId);

  // If message if found in cache, return
  if (retrieved != NULL) {

    // Increment the cache hit
    cacheHit = cacheHit + 1;
    return retrieved;
  }

  printf("Retrieve from cache failed. Retrieve from Disk...\n");

  // Open and read the file
  FILE *file = fopen("mStorage.txt", "r");

  // Check for error
  if (file == NULL) {
    printf("Error: File not found.\n");
    return NULL;
  }

  // Buffer for each line in the file
  char *lineBuffer = NULL;

  // Size of the input buffer lineBuffer
  // in
  size_t len = 0;

  // Length of each line read
  ssize_t lineLength;

  if (file == NULL) {
    printf("Cannot open file.\n");
    return NULL;
  }

  // Allocate memory for the retrieved message
  message_t *retrievedMessage = malloc(messageSize);

  // Step through each line in the file and read until
  // the correct ID is found
  while (getline(&lineBuffer, &len, file) != -1) {

    // Get ID if matched
    if (atoi(lineBuffer) == mId) {

      int id = atoi(lineBuffer);
      retrievedMessage->id = id;
      break;
    }

  }

  // If end of file is reached, no message is found
  if (getline(&lineBuffer, &len, file) == -1) {
    printf("Cannot find message. Abort.");
    free(retrievedMessage);
    free(lineBuffer);
    fclose(file);
    return NULL;
  }

  // Each message in the storage file is set up so
  // that each of the lines following the ID belongs
  // to an attribute of the message. In other words:
  // ID line: Message ID
  // ID line + 1: Time sent
  // ID line + 2: Sender
  // ID line + 3: Receiver
  // ID line + 4: Content
  // ID line + 5: Delivery status

  // Once the ID line is located, the while loop breaks
  // and the program step line by line for the next 5 lines

  // Get Time Sent
  lineLength = getline(&lineBuffer, &len, file);
  lineBuffer[lineLength - 1] = '\0'; // Remove the newline character
  strncpy(retrievedMessage->timeSent, lineBuffer, sizeof(retrievedMessage->timeSent));

  // Get Sender
  lineLength = getline(&lineBuffer, &len, file);
  lineBuffer[lineLength - 1] = '\0'; // Remove the newline character
  strncpy(retrievedMessage->sender, lineBuffer, sizeof(retrievedMessage->sender));

  // Get Receiver
  lineLength = getline(&lineBuffer, &len, file);
  lineBuffer[lineLength - 1] = '\0'; // Remove the newline character
  strncpy(retrievedMessage->receiver, lineBuffer, sizeof(retrievedMessage->receiver));

  // Get Content
  lineLength = getline(&lineBuffer, &len, file);
  lineBuffer[lineLength - 1] = '\0'; // Remove the newline character
  strncpy(retrievedMessage->content, lineBuffer, sizeof(retrievedMessage->content));

  // Get Delivery Status
  lineLength = getline(&lineBuffer, &len, file);
  retrievedMessage->delivered = atoi(lineBuffer);
  // Free the line buffer
  free(lineBuffer);

  // Close storage file when done
  fclose(file);

  // Once the message from file is retrieved, place it back onto the cache
  store_to_cache_random(retrievedMessage);

  // Increment the cache miss
  cacheMiss = cacheMiss + 1;
  
  // Return the message struct
  return retrievedMessage;
}

// This function retrieves and returns a message based on its mID
// It will search through the cache first and if the message is not in the cache it will retrieve from disk
// If the message is found on disk it will retrieve and store it on cache with LRU
message_t *retrieve_msg_LRU(int mId) {

  // Attempt to retrieve from cache first
  message_t* retrieved = retrieve_from_cache_LRU(mId);

  // If message is in the cache, return
  if (retrieved != NULL) {

    // Increment cache hit
    cacheHit = cacheHit + 1;
    return retrieved;
  }

  // Else if message is not in the cache, retrieve from disk instead
  printf("Retrieve from cache failed. Retrieve from Disk...\n");

  // Open and read the file
  FILE *file = fopen("mStorage.txt", "r");

  // Check for error
  if (file == NULL) {
    printf("Error: File not found.\n");
    return NULL;
  }

  // Buffer for each line in the file
  char *lineBuffer = NULL;

  // Size of the input buffer lineBuffer
  size_t len = 0;

  // Length of each line read
  ssize_t lineLength;

  if (file == NULL) {
    printf("Cannot open file.\n");
    return NULL;
  }

  // Allocate memory for the retrieved message
  message_t *retrievedMessage = malloc(messageSize);

  // Step through each line in the file and read until
  // the correct ID is found
  while (getline(&lineBuffer, &len, file) != -1) {

    // Get ID if matched
    if (atoi(lineBuffer) == mId) {

      int id = atoi(lineBuffer);
      retrievedMessage->id = id;
      break;
    }
  }

  // If end of file is reached, no message is found
  if (getline(&lineBuffer, &len, file) == -1) {
    printf("Cannot find message. Abort.");
    free(retrievedMessage);
    free(lineBuffer);
    fclose(file);
    return NULL;
  }

  // Each message in the storage file is set up so
  // that each of the lines following the ID belongs
  // to an attribute of the message. In other words:
  // ID line: Message ID
  // ID line + 1: Time sent
  // ID line + 2: Sender
  // ID line + 3: Receiver
  // ID line + 4: Content
  // ID line + 5: Delivery status

  // Once the ID line is located, the while loop breaks
  // and the program step line by line for the next 5 lines

  // Get Time Sent
  lineLength = getline(&lineBuffer, &len, file);
  lineBuffer[lineLength - 1] = '\0'; // Remove the newline character
  strncpy(retrievedMessage->timeSent, lineBuffer, sizeof(retrievedMessage->timeSent));

  // Get Sender
  lineLength = getline(&lineBuffer, &len, file);
  lineBuffer[lineLength - 1] = '\0'; // Remove the newline character
  strncpy(retrievedMessage->sender, lineBuffer, sizeof(retrievedMessage->sender));

  // Get Receiver
  lineLength = getline(&lineBuffer, &len, file);
  lineBuffer[lineLength - 1] = '\0'; // Remove the newline character
  strncpy(retrievedMessage->receiver, lineBuffer, sizeof(retrievedMessage->receiver));

  // Get Content
  lineLength = getline(&lineBuffer, &len, file);
  lineBuffer[lineLength - 1] = '\0'; // Remove the newline character
  strncpy(retrievedMessage->content, lineBuffer, sizeof(retrievedMessage->content));

  // Get Delivery Status
  lineLength = getline(&lineBuffer, &len, file);
  retrievedMessage->delivered = atoi(lineBuffer);
  // Free the line buffer
  free(lineBuffer);

  // Close storage file when done
  fclose(file);

  // Once the message from file is retrieved, place it back onto the cache
  store_to_cache_LRU(retrievedMessage);

  // Increment the cache miss since we did not retrieve from cache
  cacheMiss = cacheMiss + 1;

  // Return the message struct
  return retrievedMessage;
}

// This function traverses the cache and prints the message fields stored in each cache index
// It also prints the usage of each message stored in the cache to help track LRU
void traverse_cache() {

  // Iterate through the cache and print relevant info
  for (int i = 0; i < 16; i++) {

    // Check for NULL
    if (cache[i] == NULL) {
      printf("Cache entry %d: NULL\n", i);
    }
      
    else {
      printf("\n");

      message_t *cachedMessage = cache[i];
      printf("Cache entry %d:\nMessage ID: %d\n", i, cachedMessage->id);
      printf("Time created: %s\n", cachedMessage->timeSent);
      printf("Sender: %s\n", cachedMessage->sender);
      printf("Receiver: %s\n", cachedMessage->receiver);
      printf("Content: %s\n", cachedMessage->content);
      printf("Delivery status: %d\n", cachedMessage->delivered);
      printf("Usage: %d\n", usageArr[i]);
      printf("\n");
    }
  }
}

// This function frees all elements in the cache and sets it to NULL
void free_cache() {
  for (int i = 0; i < 16; i++) {
    if (cache[i] != NULL) {
      free(cache[i]);
      cache[i] = NULL;
    }
  }
}